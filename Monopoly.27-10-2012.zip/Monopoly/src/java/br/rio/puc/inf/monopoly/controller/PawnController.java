package br.rio.puc.inf.monopoly.controller;


/**
 * <p>
 * </p>
 * @author ryniere
 * @version 1.0 Created on 23/10/2012
 */
public class PawnController
{

}
