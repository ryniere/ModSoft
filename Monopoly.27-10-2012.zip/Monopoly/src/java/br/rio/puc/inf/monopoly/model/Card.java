package br.rio.puc.inf.monopoly.model;


/**
 * <p>
 * </p>
 * @author ryniere
 * @version 1.0 Created on Oct 22, 2012
 */
public class Card
{

}
